local modpath = minetest.get_modpath("homedecor_tables")

dofile(modpath.."/misc.lua")
dofile(modpath.."/endtable.lua")
dofile(modpath.."/coffeetable.lua")

