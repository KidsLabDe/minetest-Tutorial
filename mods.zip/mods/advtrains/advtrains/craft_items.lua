 
core.register_craftitem("advtrains:boiler", {
	description = attrans("Boiler"),
	inventory_image = "advtrains_boiler.png",
})

 
core.register_craftitem("advtrains:driver_cab", {
	description = attrans("driver's cab"),
	inventory_image = "advtrains_driver_cab.png",
})

 
core.register_craftitem("advtrains:wheel", {
	description = attrans("Wheel"),
	inventory_image = "advtrains_wheel.png",
})


core.register_craftitem("advtrains:chimney", {
	description = attrans("Chimney"),
	inventory_image = "advtrains_chimney.png",
})
